from flask import Flask, url_for, render_template, request
import pickle

vectorizer = pickle.load(open("vectorizer.pkl", "rb"))
classifier = pickle.load(open("REVIEWER.pkl", "rb"))

app = Flask("__name__")

@app.route("/")
def man():
	return render_template("home.html")	

@app.route("/predict", methods=['POST'])
def home():
	data = request.form['review']
	data_vect = vectorizer.transform([data])
	classified_as = classifier.predict(data_vect)
	if str(classified_as[0]) == '1':
		return render_template("thumbs_up.html")
	else:
		return render_template("thumbs_down.html")
	
if __name__ == "__main__":
	app.run(debug = True)
